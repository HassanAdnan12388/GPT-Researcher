import sys
import os

print(sys.path)  # Check if the directory containing your module is in the path

# Check contents of the package
